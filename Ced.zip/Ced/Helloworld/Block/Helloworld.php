<?php
namespace Ced\Helloworld\Block;
class Helloworld extends \Magento\Framework\View\Element\Template
{
}
?>